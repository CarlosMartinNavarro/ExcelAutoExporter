# Excel Auto Exporter - QGIS Plugin

![QGIS Plugin](https://img.shields.io/badge/QGIS-Plugin-green)
![License](https://img.shields.io/badge/license-GPL--2.0-blue)

Automatically export QGIS vector layers to Excel files (.xlsx) whenever the data changes.

## 🎯 Features

- **Automatic Export**: Monitor selected layers and export to Excel automatically on any data change
- **Selective Field Export**: Choose which fields to export for each layer
- **Custom Output Paths**: Configure individual Excel file paths for each monitored layer
- **Multiple Layer Support**: Monitor and export multiple layers simultaneously
- **User-Friendly Interface**: Easy-to-use dialog with layer search and management
- **Geometry Type Icons**: Visual identification of point, line, and polygon layers

## 📋 Requirements

- QGIS 3.0 or higher
- Python 3.6+
- Python dependencies:
  - `pandas` (for Excel export)
  - `openpyxl` (for .xlsx file format)

## 🚀 Installation

### Install Dependencies

Before using the plugin, install required Python libraries:

**Windows (OSGeo4W Shell):**


**Linux/Mac:**



### Install Plugin

1. Download the plugin ZIP file from the [Releases](https://github.com/carlosmartinnavarro/excel-auto-exporter/releases) page
2. Open QGIS
3. Go to **Plugins** → **Manage and Install Plugins** → **Install from ZIP**
4. Select the downloaded ZIP file
5. Click **Install Plugin**

## 📖 Usage

### 1. Open Plugin Configuration

Go to **Plugins** → **Excel Auto Exporter** or click the Excel icon in the toolbar.

### 2. Select Layers to Monitor

- Use the search box to filter layers by name
- Select one or multiple layers from the "Available Layers" list
- Click **"➕ Add Selected to Monitoring"**

### 3. Configure Settings

- Set the default output folder for Excel files
- Enable/disable automatic export on layer changes

### 4. Export Layers

- **Export All**: Click "📤 Export All Monitored Layers Now"
- **Export Selected**: Select a monitored layer and click "📤 Export Selected"

### 5. Automatic Updates

When auto-export is enabled, Excel files are automatically updated when:
- Features are added or deleted
- Attribute values change
- Geometries are modified

## 🛠️ Configuration

The plugin stores configuration in:



Configuration includes:
- Monitored layers and their settings
- Field selections
- Output file paths
- Auto-export preferences

## 🤝 Contributing

Contributions are welcome! Please feel free to submit a Pull Request.

1. Fork the repository
2. Create your feature branch (`git checkout -b feature/AmazingFeature`)
3. Commit your changes (`git commit -m 'Add some AmazingFeature'`)
4. Push to the branch (`git push origin feature/AmazingFeature`)
5. Open a Pull Request

## 📝 License

This plugin is licensed under the GNU General Public License v2.0 or later - see the [LICENSE](LICENSE) file for details.

## 👤 Author

**Carlos Martín Navarro**
- GitHub: [@carlosmartinnavarro](https://github.com/carlosmartinnavarro)
- Location: Heidelberg, Germany

## 🐛 Bug Reports & Feature Requests

Please report bugs and request features via [GitHub Issues](https://github.com/carlosmartinnavarro/excel-auto-exporter/issues).

## 📚 Documentation

For detailed documentation, visit the [Wiki](https://github.com/carlosmartinnavarro/excel-auto-exporter/wiki).

## ⭐ Acknowledgments

- QGIS Development Team
- Python pandas and openpyxl libraries


