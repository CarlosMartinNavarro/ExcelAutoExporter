# -*- coding: utf-8 -*-
"""
Excel Auto Exporter Plugin
Entry point for QGIS plugin system
"""

def classFactory(iface):
    """
    Load ExcelAutoExporter class from file excel_auto_exporter.py
    
    :param iface: A QGIS interface instance.
    :type iface: QgsInterface
    """
    from .excel_auto_exporter import ExcelAutoExporter
    return ExcelAutoExporter(iface)
