# -*- coding: utf-8 -*-
"""
Exporter Dialog
User interface for configuring Excel Auto Exporter
"""

import os
from qgis.PyQt.QtCore import pyqtSignal, Qt, QSize
from qgis.PyQt.QtWidgets import (
    QDialog, 
    QVBoxLayout, 
    QHBoxLayout,
    QPushButton, 
    QListWidget, 
    QLabel,
    QCheckBox,
    QLineEdit,
    QFileDialog,
    QListWidgetItem,
    QMessageBox,
    QGroupBox,
    QSplitter,
    QWidget
)
from qgis.PyQt.QtGui import QIcon, QPixmap
from qgis.core import QgsProject, QgsVectorLayer, QgsWkbTypes

class ExporterDialog(QDialog):
    """Dialog for configuring Excel Auto Exporter"""
    
    layers_config_changed = pyqtSignal()
    export_requested = pyqtSignal(str)
    export_all_requested = pyqtSignal()
    
    def __init__(self, iface, config_manager, excel_engine, parent=None):
        super().__init__(parent)
        self.iface = iface
        self.config_manager = config_manager
        self.excel_engine = excel_engine
        self.all_layers = []
        self.plugin_dir = os.path.dirname(__file__)
        self.setupUi()
        self.load_configuration()
    
    def get_geometry_icon(self, geometry_type):
        icon_path = None
        if geometry_type == QgsWkbTypes.PointGeometry:
            icon_path = os.path.join(self.plugin_dir, "point.png")
        elif geometry_type == QgsWkbTypes.LineGeometry:
            icon_path = os.path.join(self.plugin_dir, "line.png")
        elif geometry_type == QgsWkbTypes.PolygonGeometry:
            icon_path = os.path.join(self.plugin_dir, "polygon.png")
        if icon_path and os.path.exists(icon_path):
            return QIcon(icon_path)
        return QIcon()
    
    def get_geometry_type_name(self, geometry_type):
        if geometry_type == QgsWkbTypes.PointGeometry:
            return "Point"
        elif geometry_type == QgsWkbTypes.LineGeometry:
            return "Line"
        elif geometry_type == QgsWkbTypes.PolygonGeometry:
            return "Polygon"
        return "Unknown"
    
    def setupUi(self):
        self.setWindowTitle("Excel Auto Exporter - Configuration")
        self.setWindowFlags(Qt.Window | Qt.WindowMinimizeButtonHint | Qt.WindowMaximizeButtonHint | Qt.WindowCloseButtonHint)
        self.resize(800, 650)
        main_layout = QVBoxLayout()
        instructions = QLabel("💡 Select layers to monitor and export to Excel.\n💡 Search for layers by name or select multiple layers.\n💡 Changes to monitored layers will automatically update Excel files.")
        instructions.setWordWrap(True)
        instructions.setStyleSheet("QLabel { background-color: #e8f4f8; padding: 10px; border-radius: 4px; }")
        main_layout.addWidget(instructions)
        main_splitter = QSplitter(Qt.Vertical)
        main_splitter.setChildrenCollapsible(False)
        layer_widget = QWidget()
        layer_widget.setMinimumHeight(150)
        layer_layout = QVBoxLayout(layer_widget)
        layer_layout.setContentsMargins(0, 0, 0, 0)
        layer_group = QGroupBox("🔍 Available Layers (Search & Select)")
        layer_group_layout = QVBoxLayout()
        search_layout = QHBoxLayout()
        search_layout.addWidget(QLabel("Search:"))
        self.search_box = QLineEdit()
        self.search_box.setPlaceholderText("Type layer name to filter...")
        self.search_box.textChanged.connect(self.filter_layers)
        search_layout.addWidget(self.search_box)
        clear_search_btn = QPushButton("✖")
        clear_search_btn.setMaximumWidth(30)
        clear_search_btn.setToolTip("Clear search")
        clear_search_btn.clicked.connect(lambda: self.search_box.clear())
        search_layout.addWidget(clear_search_btn)
        layer_group_layout.addLayout(search_layout)
        self.layer_list = QListWidget()
        self.layer_list.setSelectionMode(QListWidget.MultiSelection)
        self.layer_list.setIconSize(QSize(20, 20))
        layer_group_layout.addWidget(self.layer_list)
        self.layer_count_label = QLabel("Layers: 0")
        self.layer_count_label.setStyleSheet("QLabel { color: #666; font-size: 10px; }")
        layer_group_layout.addWidget(self.layer_count_label)
        buttons_row = QHBoxLayout()
        refresh_btn = QPushButton("🔄 Refresh List")
        refresh_btn.clicked.connect(self.refresh_layer_list)
        refresh_btn.setToolTip("Reload all layers from project")
        buttons_row.addWidget(refresh_btn)
        buttons_row.addStretch()
        self.add_layer_btn = QPushButton("➕ Add Selected to Monitoring")
        self.add_layer_btn.clicked.connect(self.add_layers_to_monitoring)
        self.add_layer_btn.setStyleSheet("QPushButton { font-weight: bold; background-color: #2196F3; color: white; padding: 6px; }")
        buttons_row.addWidget(self.add_layer_btn)
        layer_group_layout.addLayout(buttons_row)
        layer_group.setLayout(layer_group_layout)
        layer_layout.addWidget(layer_group)
        main_splitter.addWidget(layer_widget)
        monitored_widget = QWidget()
        monitored_widget.setMinimumHeight(120)
        monitored_layout = QVBoxLayout(monitored_widget)
        monitored_layout.setContentsMargins(0, 0, 0, 0)
        monitored_group = QGroupBox("📊 Monitored Layers (Auto-Export Enabled)")
        monitored_group_layout = QVBoxLayout()
        self.monitored_list = QListWidget()
        self.monitored_list.setIconSize(QSize(20, 20))
        monitored_group_layout.addWidget(self.monitored_list)
        monitored_btn_layout = QHBoxLayout()
        self.export_one_btn = QPushButton("📤 Export Selected")
        self.export_one_btn.clicked.connect(self.export_selected_layer)
        self.export_one_btn.setToolTip("Export only the selected monitored layer")
        monitored_btn_layout.addWidget(self.export_one_btn)
        self.remove_layer_btn = QPushButton("➖ Remove Selected")
        self.remove_layer_btn.clicked.connect(self.remove_layer_from_monitoring)
        self.remove_layer_btn.setToolTip("Stop monitoring the selected layer")
        monitored_btn_layout.addWidget(self.remove_layer_btn)
        monitored_group_layout.addLayout(monitored_btn_layout)
        monitored_group.setLayout(monitored_group_layout)
        monitored_layout.addWidget(monitored_group)
        main_splitter.addWidget(monitored_widget)
        main_splitter.setSizes([400, 250])
        main_splitter.setStretchFactor(0, 3)
        main_splitter.setStretchFactor(1, 2)
        main_layout.addWidget(main_splitter)
        settings_group = QGroupBox("⚙️ Settings")
        settings_layout = QVBoxLayout()
        self.auto_export_checkbox = QCheckBox("✅ Enable automatic export on layer changes")
        self.auto_export_checkbox.setChecked(self.config_manager.is_auto_export_enabled())
        self.auto_export_checkbox.stateChanged.connect(self.on_auto_export_changed)
        self.auto_export_checkbox.setStyleSheet("QCheckBox { font-weight: bold; }")
        settings_layout.addWidget(self.auto_export_checkbox)
        folder_layout = QHBoxLayout()
        folder_layout.addWidget(QLabel("📁 Default output folder:"))
        self.output_folder_edit = QLineEdit()
        self.output_folder_edit.setText(self.config_manager.get_default_output_folder())
        folder_layout.addWidget(self.output_folder_edit)
        browse_btn = QPushButton("Browse...")
        browse_btn.clicked.connect(self.browse_output_folder)
        folder_layout.addWidget(browse_btn)
        settings_layout.addLayout(folder_layout)
        settings_group.setLayout(settings_layout)
        main_layout.addWidget(settings_group)
        button_layout = QHBoxLayout()
        self.export_all_btn = QPushButton("📤 Export All Monitored Layers Now")
        self.export_all_btn.clicked.connect(self.export_all_layers)
        self.export_all_btn.setStyleSheet("QPushButton { background-color: #4CAF50; color: white; font-weight: bold; padding: 8px; }")
        button_layout.addWidget(self.export_all_btn)
        button_layout.addStretch()
        close_btn = QPushButton("Close")
        close_btn.clicked.connect(self.close)
        close_btn.setMinimumWidth(100)
        button_layout.addWidget(close_btn)
        main_layout.addLayout(button_layout)
        self.setLayout(main_layout)
        self.refresh_layer_list()
        self.refresh_monitored_list()
    
    def refresh_layer_list(self):
        self.layer_list.clear()
        self.all_layers = []
        for layer in QgsProject.instance().mapLayers().values():
            if isinstance(layer, QgsVectorLayer):
                self.all_layers.append(layer.name())
                geom_type = layer.geometryType()
                icon = self.get_geometry_icon(geom_type)
                geom_name = self.get_geometry_type_name(geom_type)
                display_text = f"{layer.name()} ({geom_name})"
                item = QListWidgetItem(icon, display_text)
                item.setData(Qt.UserRole, layer.name())
                item.setToolTip(f"Type: {geom_name}\nFields: {len(layer.fields())}\nFeatures: {layer.featureCount()}")
                self.layer_list.addItem(item)
        self.update_layer_count()
        if self.search_box.text():
            self.filter_layers(self.search_box.text())
    
    def filter_layers(self, search_text):
        search_text = search_text.lower()
        visible_count = 0
        for i in range(self.layer_list.count()):
            item = self.layer_list.item(i)
            layer_name = item.data(Qt.UserRole).lower()
            matches = search_text in layer_name
            item.setHidden(not matches)
            if matches:
                visible_count += 1
        total = len(self.all_layers)
        if search_text:
            self.layer_count_label.setText(f"Showing: {visible_count} of {total} layers")
            self.layer_count_label.setStyleSheet("QLabel { color: #2196F3; font-weight: bold; }")
        else:
            self.layer_count_label.setText(f"Total layers: {total}")
            self.layer_count_label.setStyleSheet("QLabel { color: #666; }")
    
    def update_layer_count(self):
        total = len(self.all_layers)
        self.layer_count_label.setText(f"Total layers: {total}")
        self.layer_count_label.setStyleSheet("QLabel { color: #666; }")
    
    def refresh_monitored_list(self):
        self.monitored_list.clear()
        monitored = self.config_manager.get_monitored_layers()
        for layer_name, config in monitored.items():
            output_path = config.get('output_path', 'Not configured')
            fields_count = len(config.get('fields', []))
            layer = self.get_layer_by_name(layer_name)
            if layer:
                icon = self.get_geometry_icon(layer.geometryType())
            else:
                icon = QIcon()
            display_text = f"{layer_name} → {os.path.basename(output_path)} ({fields_count} fields)"
            item = QListWidgetItem(icon, display_text)
            item.setData(Qt.UserRole, layer_name)
            item.setToolTip(f"Output: {output_path}\nFields exported: {fields_count}")
            self.monitored_list.addItem(item)
    
    def add_layers_to_monitoring(self):
        selected_items = self.layer_list.selectedItems()
        if not selected_items:
            QMessageBox.warning(self, "No Selection", "Please select at least one layer to add.")
            return
        added_count = 0
        skipped_count = 0
        for item in selected_items:
            layer_name = item.data(Qt.UserRole)
            monitored = self.config_manager.get_monitored_layers()
            if layer_name in monitored:
                skipped_count += 1
                continue
            layer = self.get_layer_by_name(layer_name)
            if layer and layer.isValid():
                fields = [field.name() for field in layer.fields()]
                default_folder = self.output_folder_edit.text()
                if not default_folder:
                    default_folder = self.config_manager.get_default_output_folder()
                output_filename = f"{layer_name}.xlsx"
                output_path = os.path.join(default_folder, output_filename)
                self.config_manager.add_monitored_layer(layer_name, fields, output_path)
                added_count += 1
        self.refresh_monitored_list()
        self.layers_config_changed.emit()
        message = f"✅ {added_count} layer(s) added to monitoring."
        if skipped_count > 0:
            message += f"\n⚠️ {skipped_count} layer(s) skipped (already monitored)."
        QMessageBox.information(self, "Layers Added", message)
    
    def remove_layer_from_monitoring(self):
        selected_items = self.monitored_list.selectedItems()
        if not selected_items:
            QMessageBox.warning(self, "No Selection", "Please select a monitored layer to remove.")
            return
        for item in selected_items:
            layer_name = item.data(Qt.UserRole)
            self.config_manager.remove_monitored_layer(layer_name)
        self.refresh_monitored_list()
        self.layers_config_changed.emit()
        QMessageBox.information(self, "Layer Removed", f"✅ {len(selected_items)} layer(s) removed from monitoring.")
    
    def export_selected_layer(self):
        selected_items = self.monitored_list.selectedItems()
        if not selected_items:
            QMessageBox.warning(self, "No Selection", "Please select a layer to export.")
            return
        for item in selected_items:
            layer_name = item.data(Qt.UserRole)
            self.export_requested.emit(layer_name)
    
    def export_all_layers(self):
        self.export_all_requested.emit()
    
    def browse_output_folder(self):
        folder = QFileDialog.getExistingDirectory(self, "Select Default Output Folder", self.output_folder_edit.text())
        if folder:
            self.output_folder_edit.setText(folder)
            self.config_manager.set_default_output_folder(folder)
    
    def on_auto_export_changed(self, state):
        enabled = (state == Qt.Checked)
        self.config_manager.set_auto_export(enabled)
        self.layers_config_changed.emit()
    
    def load_configuration(self):
        self.auto_export_checkbox.setChecked(self.config_manager.is_auto_export_enabled())
        self.output_folder_edit.setText(self.config_manager.get_default_output_folder())
    
    def get_layer_by_name(self, layer_name):
        for layer in QgsProject.instance().mapLayers().values():
            if isinstance(layer, QgsVectorLayer) and layer.name() == layer_name:
                return layer
        return None
